# S43 · تزریق وابستگی عمیق (Dependency Injection)

DI scoped را در یک scope دوبار و سپس scope تازه resolve کن و هویت‌ها را مقایسه کن.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
True
False
```

معیارهای review:
- تمام scopeها آزاد شوند.
- از root سرویس scoped resolve نکن.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
