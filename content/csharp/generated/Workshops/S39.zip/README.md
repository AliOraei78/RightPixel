# S39 · سریال‌سازی مدرن JSON و شبکه‌سازی ایمن

DTO سفارش را با JsonSerializerContext رفت‌وبرگشت بده؛ به شبکهٔ واقعی وابسته نباش.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
42
```

معیارهای review:
- از overload دارای context استفاده شود.
- اعتبارسنجی کسب‌وکار را با deserialization یکسان فرض نکن.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
