# S37 · Roslyn Source Generators و Native AOT

generator همراه پروژهٔ کارگاه یک کلاس ثابت تولید می‌کند؛ مصرف‌کننده را بساز و خروجی deterministic را بررسی کن. پروژهٔ Generator کنار کارگاه قرار دارد.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
course-v1
True
```

معیارهای review:
- کلاس BuildStamp را در مصرف‌کننده دستی تعریف نکن.
- خروجی build دوباره باید یکسان بماند؛ تحلیلگر از ProjectReference متصل شده است.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
