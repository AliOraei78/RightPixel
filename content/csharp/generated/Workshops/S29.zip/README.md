# S29 · برنامه‌نویسی ناامن (Unsafe & Native Interop)

آرایه را فقط در یک fixed کوتاه بخوان و مجموع دو عنصر را چاپ کن.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
7
```

معیارهای review:
- pointer نباید از محدودهٔ fixed بیرون برود.
- AllowUnsafeBlocks فقط در پروژهٔ کارگاه فعال باشد.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
