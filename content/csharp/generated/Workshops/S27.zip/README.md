# S27 · برنامه‌نویسی High-Performance با Span و Memory

عدد بعد از = را بدون Substring و با Span parse کن.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
42
```

معیارهای review:
- زیررشتهٔ جدید نساز.
- مسیر نبودن جداکننده مشخص باشد.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
