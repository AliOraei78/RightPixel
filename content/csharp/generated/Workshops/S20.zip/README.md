# S20 · مکانیزم درونی LINQ و تله‌های پرفورمنس

iterator با شمارش side effect بساز و نشان بده materialize فقط یک بار بدنه را پیمایش می‌کند.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
6
3
3
```

معیارهای review:
- Count و Sum نباید visits را دوباره افزایش دهند.
- هزینهٔ snapshot را توضیح بده.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
