# S35 · همزمانی پیشرفته: Channels و Reactive Patterns

producer/consumer با ظرفیت 2 بساز؛ 1 تا 5 را بدون drop جمع کن و completion را اعلام کن.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
15
```

معیارهای review:
- producer و consumer باید امکان پیشروی هم‌زمان داشته باشند.
- جریان با Complete پایان یابد.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
