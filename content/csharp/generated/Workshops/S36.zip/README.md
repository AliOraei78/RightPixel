# S36 · ویژگی‌ها (Attributes) و Reflection عمیق

attribute برچسب بساز، روی نوع بگذار و مقدار آن را با Reflection بخوان.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
audit
```

معیارهای review:
- AttributeUsage فقط Class را مجاز کند.
- نبودن attribute مسیر null معتبر داشته باشد.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
