# S11 · ژنریک‌ها (Generics) و محدودیت‌ها (Constraints)

Max ژنریک بساز و بدون object یا dynamic برای int و string اجرا کن.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
8
b
```

معیارهای review:
- هر دو نوع با یک متد کار کنند.
- قید فقط قابلیت لازم را بخواهد.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
