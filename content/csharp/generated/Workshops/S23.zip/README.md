# S23 · لاگینگ، ردیابی و Observability مدرن

یک Activity با listener بساز، یک tag سفارش بده و ثابت کن span واقعاً ایجاد شده است.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
True
```

معیارهای review:
- listener فقط به source همین تمرین گوش بدهد.
- منابع listener و Activity آزاد شوند.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
