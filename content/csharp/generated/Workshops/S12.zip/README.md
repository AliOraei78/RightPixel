# S12 · واریانس در ژنریک‌ها: Covariance و Contravariance

تولیدکنندهٔ string و مصرف‌کنندهٔ object را در یک pipeline با واریانس متصل کن.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
Ada
Lin
2
```

معیارهای review:
- از Cast<object>() برای پنهان‌کردن واریانس استفاده نکن.
- جهت تبدیل Action را توضیح بده.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
