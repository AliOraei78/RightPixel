# S30 · مبانی تردها، ThreadPool و Synchronization

شمارنده را در ده کار async با SemaphoreSlim محافظت کن و هیچ افزایش گم نشود.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
10
```

معیارهای review:
- await داخل lock قرار نگیرد.
- همهٔ مسیرها مجوز را آزاد کنند.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
