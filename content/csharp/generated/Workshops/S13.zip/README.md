# S13 · سیستم ایمنی نال (Nullable Reference Types - NRT)

نام ورودی اختیاری را trim کن و null یا whitespace را به guest تبدیل کن.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
guest
Ada
```

معیارهای review:
- از ! برای دور زدن تحلیل استفاده نکن.
- null، فاصله و نام معتبر را در review بررسی کن.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
