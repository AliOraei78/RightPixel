# S14 · الگوخوانی مدرن (Deep Pattern Matching)

قیمت سفارش مثبت و شناسهٔ معتبر را با property pattern ارزیابی کن.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
True
False
```

معیارهای review:
- null نباید exception ایجاد کند.
- قانون اعتبار در یک predicate روشن باشد.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
