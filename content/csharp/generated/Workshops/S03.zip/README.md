# S03 · تبدیل انواع، عملیات و Boxing/Unboxing

جمع امن دو int را با خروجی overflow در حالت سرریز پیاده کن.

پیش‌نیاز: .NET SDK 10. پروژه با C# 13 تنظیم شده است.
Program.cs کد شروع است. آن را کامل کن و اجرا کن:

```powershell
dotnet run --project Workshop.csproj
```

خروجی مورد انتظار:
```text
overflow
```

معیارهای review:
- فقط OverflowException را بگیر.
- checked باید دور خود عملیات جمع باشد.

کد دلخواه در سرور بازی اجرا نمی‌شود؛ اجرای پروژه روی دستگاه خودت است. راه‌حل در Reference.cs.txt برای مقایسه است و در compile وارد نمی‌شود.
